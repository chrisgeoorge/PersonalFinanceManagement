package com.financemanagement.PFMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfmsApplicationTests {

	@Test
	void contextLoads() {
	}

}

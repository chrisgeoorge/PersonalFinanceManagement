package com.financemanagement.PFMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PfmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PfmsApplication.class, args);
	}

}
